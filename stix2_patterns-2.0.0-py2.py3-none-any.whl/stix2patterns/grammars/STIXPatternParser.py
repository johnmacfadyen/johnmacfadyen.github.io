# Update or remove for 2.0.0
from ..v20.grammars.STIXPatternParser import *  # noqa: F401